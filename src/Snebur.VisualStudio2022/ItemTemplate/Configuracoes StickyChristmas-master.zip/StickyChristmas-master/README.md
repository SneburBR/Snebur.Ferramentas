﻿# Sticky Christmas

[![Build status](https://ci.appveyor.com/api/projects/status/2761x092jl4c53h1?svg=true)](https://ci.appveyor.com/project/madskristensen/stickychristmas)

A simulation of what happens when you spill cookies and eggnog into your keyboard while coding

Download this extension from the [Marketplace](https://marketplace.visualstudio.com/items?itemName=MadsKristensen.StickyChristmas)
or get the [CI build](https://www.vsixgallery.com/extension/846a4ff2-2fc1-4bca-861a-ecc3c0f02eba).

-----------------------------------------

❄ coming soon...

## License
[Apache 2.0](LICENSE)
