﻿
namespace $rootnamespace$
{
    export class $safeitemrootname$ extends Zyoncore.UI.Pagina
    {
        public constructor(controlePai: Zyoncore.UI.BaseControle) 
        {
            super(controlePai);
            this.EventoCarregado.AddHandler(this.Pagina_Carregada, this);
        }

        private Pagina_Carregada(provedor: any, e: EventArgs) 
        {
            //pagina carregada
        }
    }
}
