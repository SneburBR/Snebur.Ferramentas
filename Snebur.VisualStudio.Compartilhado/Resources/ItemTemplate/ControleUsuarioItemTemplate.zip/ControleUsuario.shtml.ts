﻿
namespace $rootnamespace$
{
    export class $safeitemrootname$ extends Zyoncore.UI.ControleUsuario
    {
        public constructor(controlePai: Zyoncore.UI.BaseControle, refElemento: HTMLElement | string) 
        {
            super(controlePai, refElemento);
            this.EventoCarregado.AddHandler(this.Controle_Carregado, this);
        }

        private Controle_Carregado(provedor: any, e: EventArgs) 
        {
            //controle carregada
        }
	}
}
